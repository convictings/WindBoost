# WindBoost (Fabric 26.2)

A small server-side Fabric mod prototype.

## Behavior
- Detects the explosion of a thrown `WindCharge`.
- If its owner is a player and is within 4 blocks of the burst position, the owner gets an upward velocity of at least 1.0.
- X/Z velocity is preserved.
- Fall distance is reset.
- Other players are not boosted by someone else's wind charge.

## Build
Requires JDK 25 and Gradle 9.5.1 or newer.

Run:
    gradle build

The JAR is written to `build/libs/`.

## GitHub Actions
Upload this project to a GitHub repository. The included workflow builds it on each push.
After the workflow completes, open the run, scroll to **Artifacts**, and download `WindBoost-26.2`.

## Important testing note
This is an initial source build, not a tested JAR. Minecraft 26.2's exact runtime mappings and mixin target should be verified by a successful cloud build and an in-game test. The boost currently uses a 4-block distance check around the explosion position as a practical approximation of the wind burst's hit area.
