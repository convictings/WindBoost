package com.miko.windboost.mixin;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.hurtingprojectile.windcharge.WindCharge;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WindCharge.class)
public abstract class WindChargeMixin {
    @Shadow
    public abstract Entity getOwner();

    @Inject(method = "explode", at = @At("RETURN"))
    private void windboost$boostThrower(Vec3 explosionPosition, CallbackInfo ci) {
        Entity owner = this.getOwner();

        // Only boost the player who threw this wind charge.
        if (!(owner instanceof ServerPlayer player)) {
            return;
        }

        // Match the wind burst's nearby knockback area; avoid boosting from distant bursts.
        if (player.position().distanceToSqr(explosionPosition) > 16.0) {
            return;
        }

        Vec3 current = player.getDeltaMovement();

        // Preserve horizontal momentum and replace downward velocity with an upward launch.
        player.setDeltaMovement(current.x, Math.max(current.y, 1.0), current.z);
        player.resetFallDistance();
        player.hurtMarked = true;
    }
}
